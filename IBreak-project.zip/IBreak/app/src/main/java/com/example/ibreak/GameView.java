package com.example.ibreak;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import androidx.annotation.NonNull;

import com.example.ibreak.services.IService;
import com.example.ibreak.services.IServiceDrawables;
import com.example.ibreak.services.controls.IControlsService;
import com.example.ibreak.services.devop.DevopService;
import com.example.ibreak.services.globals.IGlobalsService;
import com.example.ibreak.services.Services;
import com.example.ibreak.services.ServicesFactory;

public class GameView extends SurfaceView implements SurfaceHolder.Callback {
    private MainThread mainThread;
    IServiceDrawables backgroundsService;
    IServiceDrawables obstaclesService;
    IServiceDrawables entitiesService;
    IServiceDrawables hudService;
    IControlsService controlsService;
    DevopService devopService;
    IGlobalsService globalsService;

    @Override
    public void draw(Canvas canvas) {
        super.draw(canvas);

        if (canvas != null) {
            canvas.drawColor(Color.BLACK);
            backgroundsService.draw(canvas);
            obstaclesService.draw(canvas);
            entitiesService.draw(canvas);
            hudService.draw(canvas);
            devopService.draw(canvas);
        }
    }

    public GameView(Context context) {
        super(context);
        globalsService = ServicesFactory.getGlobals();

        if (globalsService != null) {
            globalsService.setResources(getResources());
            globalsService.setGameView(this);
        }

        backgroundsService = ServicesFactory.getDrawables(Services.BACKGROUNDS);
        obstaclesService = ServicesFactory.getDrawables(Services.OBSTACLES);
        entitiesService = ServicesFactory.getDrawables(Services.ENTITIES);
        hudService = ServicesFactory.getDrawables(Services.HUD);
        controlsService = ServicesFactory.getControls();
        devopService = ServicesFactory.getDevops();

        if (backgroundsService != null && obstaclesService != null && entitiesService != null && controlsService != null && hudService != null && devopService != null) {
            mainThread = new MainThread(getHolder(), this);
            setFocusable(true);
            getHolder().addCallback(this);
        }
    }

    @Override
    public void surfaceCreated(@NonNull SurfaceHolder surfaceHolder) {
        mainThread.setRunning(true);
        mainThread.start();
    }

    @Override
    public void surfaceChanged(@NonNull SurfaceHolder surfaceHolder, int i, int i1, int i2) {}

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        boolean retry = true;
        while (retry) {
            try {
                mainThread.setRunning(false);
                mainThread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            retry = false;
        }
    }

    public void update(float delta) {
        entitiesService.update(delta);
        obstaclesService.update(delta);
        hudService.update(delta);
        globalsService.update();
    }
}
