package com.example.ibreak.services.globals;

import android.content.res.Resources;

import com.example.ibreak.Constants;
import com.example.ibreak.GameView;
import com.example.ibreak.modules.screen.Screen;
import com.example.ibreak.services.ServicesFactory;
import com.example.ibreak.services.controls.ControlsService;
import com.example.ibreak.services.entities.EntitiesService;
import com.example.ibreak.services.obstacles.ObstaclesService;

public class GlobalsService implements IGlobalsService {
    private static GlobalsService _instance = null;
    private Resources _resources = null;
    private GameView _gameView = null;
    private GameStates _gameState = GameStates.READY;
    private int _score = 0;
    private int _level = 1;
    private int _lives = Constants.LIVES_INIT;

    public static GlobalsService getInstance() {
        if (_instance == null)
            _instance = new GlobalsService();

        return _instance;
    }

    // Getters
    public Resources getResources() { return this._resources; }
    public GameView getGameView() { return this._gameView; }
    public GameStates getGameState() { return this._gameState; }
    public int getScore() { return this._score; }
    public int getLives() { return this._lives; }
    public int getLevel() { return this._level; }

    // Setters
    public void setResources(Resources resources) { this._resources = resources; }
    public void setGameView(GameView gameView) { this._gameView = gameView; }
    public void setGameState(GameStates gameState) { this._gameState = gameState; }
    public void setScore(int score) { this._score = score; }
    public void setLives(int lives) { this._lives = lives; }
    public void setLevel(int level) { this._level = level; }

    // Booleans
    public boolean isGameState(GameStates state) { return this.getGameState() == state; }

    // Actions
    public void increaseScore(int amount) { this._score += amount; }
    public void decreaseLives(int amount) { this._lives -= amount; }

    public void newLevel() {
        this.setLives(this.getLives()+1);
        EntitiesService.getInstance().restart();
        ObstaclesService.getInstance().restart();
        ControlsService.getInstance().setInitTouch(false);
        this.setLevel(this.getLevel()+1);
        setGameState(GameStates.READY);
    }

    public void restart() {
        this.setLives(Constants.LIVES_INIT);
        this.setScore(0);
        this.setLevel(0);
        ControlsService.getInstance().setInitTouch(false);
        EntitiesService.getInstance().restart();
        ObstaclesService.getInstance().restart();
        setGameState(GameStates.READY);
    }

    public void update() {
        if (this.getLives() <= 0) {
            this.setGameState(GameStates.GAME_DEAD);
        }
    }
}
