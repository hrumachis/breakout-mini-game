package com.example.ibreak.services.textures;

import com.example.ibreak.R;

public class TextureSelector {
    static int get(Textures textureName) {
        switch (textureName) {
            case BG0: return R.drawable.bg0;
            case BG1: return R.drawable.bg1;
            case BRICK0: return R.drawable.brick0;
            case BRICK1: return R.drawable.brick1;
            case BRICK2: return R.drawable.brick2;
            case BALL0: return R.drawable.ball0;
            case BALL1: return R.drawable.ball1;
            case PADDLE0: return R.drawable.paddle0;

        }
        return 0;
    }
}
