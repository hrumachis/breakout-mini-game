package com.example.ibreak.modules.obstacle;

import android.graphics.Canvas;

import com.example.ibreak.modules.position.IVector2f;
import com.example.ibreak.modules.texture.ITexture;

public interface IObstacle {
    // Getters
    IVector2f getPos();
    int getWidth();
    int getHeight();
    int getIndex();
    int getScore();

    // Setters
    IObstacle setTexture(ITexture texture);
    IObstacle setWidth(int width);
    IObstacle setHeight(int height);
    IObstacle setVisibility(boolean visibility);

    // Booleans
    boolean isVisible();
    boolean isCollidingDown(IVector2f pos, IVector2f velocity);
    boolean isCollidingUp(IVector2f pos, IVector2f velocity);
    boolean isCollidingLeft(IVector2f pos, IVector2f velocity);
    boolean isCollidingRight(IVector2f pos, IVector2f velocity);

    // Events
    void onCollide();

    // Actions
    void draw(Canvas canvas);
    void resize();
}
