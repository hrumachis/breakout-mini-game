package com.example.ibreak.modules.hud.builders;

import android.graphics.Color;
import android.graphics.Paint;

import com.example.ibreak.modules.hud.Hud;
import com.example.ibreak.modules.hud.IHud;
import com.example.ibreak.modules.screen.Screen;

public class TitleHudBuilder {
    public static final IHud build() {
        IHud hud = new Hud();
        hud.getTextPos().setX(((int) Screen.getWidth() / 2));
        hud.getTextPos().setY((int) (300 * Screen.calcScale()));
        hud.getTextPaint().setColor(Color.argb(220, 245, 236, 206));
        hud.getTextPaint().setTextSize((int) (60 * Screen.calcScale()));
        hud.getTextPaint().setTextAlign(Paint.Align.CENTER);
        hud.setText("You scored 0 Points");

        return hud;
    }
}
