package com.example.ibreak.modules.hud.builders;

import android.graphics.Color;
import android.graphics.Paint;

import com.example.ibreak.modules.hud.Hud;
import com.example.ibreak.modules.hud.IHud;
import com.example.ibreak.modules.screen.Screen;
import com.example.ibreak.services.ServicesFactory;
import com.example.ibreak.services.globals.GlobalsService;
import com.example.ibreak.services.hud.HudId;

public class ExitButtonHudBuilder {
    public static final IHud build() {
        IHud hud = new Hud();

        // Background
        hud.setWidth((int) (300 * Screen.calcScale()));
        hud.setHeight((int) (100 * Screen.calcScale()));
        hud.getBgPaint().setColor(Color.argb(120, 163, 77, 161));
        hud.useBackground(true);
        hud.getBgPos().setX(((int) Screen.getWidth() / 2 - hud.getWidth() - 100));
        hud.getBgPos().setY((int) (600 * Screen.calcScale()));

        // Text
        hud.getTextPaint().setColor(Color.argb(200, 245, 236, 206));
        hud.getTextPaint().setTextSize((int) (40 * Screen.calcScale()));
        hud.getTextPaint().setTextAlign(Paint.Align.CENTER);
        hud.getTextPaint().setStrokeWidth(20);
        hud.getTextPos().setX(((int) hud.getBgPos().getX() + hud.getWidth() / 2));
        hud.getTextPos().setY(((int) hud.getBgPos().getY() + hud.getHeight() / 2 + 18 * Screen.calcScale()));
        hud.setText("EXIT");

        // onClick
        hud.setClickable(true);
        hud.setCallback(() -> {
            android.os.Process.killProcess(android.os.Process.myPid());
            System.exit(1);
            return null;
        });

        return hud;
    }
}
