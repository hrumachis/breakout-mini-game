package com.example.ibreak.services.obstacles;

import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Color;
import android.util.Log;

import com.example.ibreak.Constants;
import com.example.ibreak.modules.obstacle.IObstacle;
import com.example.ibreak.modules.obstacle.Obstacle;
import com.example.ibreak.modules.position.IVector2f;
import com.example.ibreak.modules.position.Vector2f;
import com.example.ibreak.modules.screen.Screen;
import com.example.ibreak.services.IServiceDrawables;
import com.example.ibreak.services.devop.Pointer;
import com.example.ibreak.services.devop.Pointers;
import com.example.ibreak.services.globals.GameStates;
import com.example.ibreak.services.globals.GlobalsService;
import com.example.ibreak.services.globals.IGlobalsService;
import com.example.ibreak.services.ServicesFactory;
import com.example.ibreak.services.textures.TextureBuilder;
import com.example.ibreak.services.textures.Textures;

import java.util.HashMap;

public class ObstaclesService implements IObstaclesService {
    private static ObstaclesService _instance = null;
    private HashMap<String, IObstacle> _obstacles = new HashMap<String, IObstacle>();
    private int _obstaclesCount = Constants.BRICKS_COLUMNS * Constants.BRICKS_ROWS;

    public static ObstaclesService getInstance() {
        if (_instance == null)
            _instance = new ObstaclesService();

        return _instance;
    }

    public ObstaclesService() {
        IGlobalsService globalsService = ServicesFactory.getGlobals();

        if (globalsService != null && globalsService.getResources() != null) {
            this.load(globalsService.getResources());
        }
    }

    // Getters
    public IObstacle get(int index) {
        return this._obstacles.get(Integer.toString(index));
    }
    public IObstacle getByObserverPos(float x, float y) {
        int indexX = (int) Math.floor((x - Screen.getWidth() / 2) / (int) Math.floor(114*Screen.calcScale())) - (-Constants.BRICKS_COLUMNS/2);
        int indexY = (int) Math.floor((y - Screen.calcOffSet().getY() - 100) / (int) Math.floor(57*Screen.calcScale()));

        // *** Devops
        if (ServicesFactory.getDevops().isDevopsOn()) {
            Pointer pointer1 = ServicesFactory.getDevops().get(Pointers.COLLISION_SEARCH_POINTER);

            if (pointer1 != null) {
                IVector2f indexPos = new Vector2f();
                indexPos.setX((-Constants.BRICKS_COLUMNS / 2 + indexX) * (int) Math.floor(114 * Screen.calcScale()) + Screen.getWidth() / 2);
                indexPos.setY(indexY * (int) Math.floor(57 * Screen.calcScale()) + Screen.calcOffSet().getY() + 100);
                pointer1.getPaint().setColor(Color.YELLOW);
                pointer1.getPos().setX(indexPos.getX());
                pointer1.getPos().setY(indexPos.getY());
            }
        }

        // Found existing bricks
        if (indexX >= 0 && indexX < Constants.BRICKS_COLUMNS &&
            indexY >= 0 && indexY < Constants.BRICKS_ROWS) {
            IObstacle obstacle = this.get((int) 1e3 * indexX + indexY);

            // *** Devops
            if (ServicesFactory.getDevops().isDevopsOn()) {
                Pointer pointer0 = ServicesFactory.getDevops().get(Pointers.COLLISION_POINTER);

                if (pointer0 != null) {
                    pointer0.getPaint().setColor(Color.GREEN);
                    pointer0.getPos().setX(obstacle.getPos().getX());
                    pointer0.getPos().setY(obstacle.getPos().getY());
                }
            }

            return obstacle;
        }

        return null;
    }

    // Setters
    public void set(int index, IObstacle obstacle) {  this._obstacles.put(Integer.toString(index), obstacle); }

    // Actions
    public void decreaseObstaclesCount() {
        this._obstaclesCount--;
    }

    public void restart() {
        this._obstaclesCount = Constants.BRICKS_COLUMNS * Constants.BRICKS_ROWS;

        for (int x = 0; x < Constants.BRICKS_COLUMNS; x++) {
            for (int y = 0; y < Constants.BRICKS_ROWS; y++) {
                int index = (int) (1e3 * x + y);
                IObstacle obstacle = this.get(index);

                if (obstacle != null) {
                    obstacle.setVisibility(true);
                }
            }
        }
    }

    public void draw(Canvas canvas) {
        for (int x = 0; x < Constants.BRICKS_COLUMNS; x++) {
            for (int y = 0; y < Constants.BRICKS_ROWS; y++) {
                int index = (int) (1e3 * x + y);
                IObstacle obstacle = this.get(index);

                if (obstacle != null) {
                    obstacle.draw(canvas);
                }
            }
        }
    }

    public void update(float delta) {
        if (this._obstaclesCount <= 0) {
            GlobalsService.getInstance().setGameState(GameStates.GAME_WIN);
        }
    }

    private void load(Resources resources) {
        for (int x = 0; x < Constants.BRICKS_COLUMNS; x++) {
            for (int y = 0; y < Constants.BRICKS_ROWS; y++) {
                int index = (int) (1e3 * x + y);

                IObstacle obstacle = new Obstacle()
                    .setTexture(TextureBuilder.build(resources, Textures.BRICK1))
                    .setWidth(114)
                    .setHeight(57);

                obstacle.resize();

                // Centered bricks
                obstacle.getPos().setX((-Constants.BRICKS_COLUMNS/2 + x) * obstacle.getWidth() + Screen.getWidth() / 2);
                obstacle.getPos().setY(y * obstacle.getHeight() + Screen.calcOffSet().getY() + 100);

                this.set(index, obstacle);
            }
        }
    }
}
