package com.example.ibreak.modules.hud;

import android.graphics.Canvas;
import android.graphics.Paint;

import com.example.ibreak.modules.position.IVector2f;

import java.util.concurrent.Callable;

public interface IHud {
    // Getters
    Paint getBgPaint();
    Paint getTextPaint();
    IVector2f getBgPos();
    IVector2f getTextPos();
    int getWidth();
    int getHeight();
    int getPadding();
    String getText();

    // Setters
    void setWidth(int width);
    void setHeight(int height);
    void setPadding(int padding);
    void useBackground(boolean use);
    void setVisibility(boolean visibility);
    void setText(String text);
    void setClickable(boolean clickable);
    void setCallback(Callable callback);

    // Booleans
    boolean haveBackground();
    boolean haveText();
    boolean isClickable();
    boolean isInArea(IVector2f pos);

    // Events
    void onClick() throws Exception;

    // Actions
    void draw(Canvas canvas);
}
