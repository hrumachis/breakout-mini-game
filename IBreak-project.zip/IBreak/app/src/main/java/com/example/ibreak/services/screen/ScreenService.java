package com.example.ibreak.services.screen;

import com.example.ibreak.services.IService;
import com.example.ibreak.services.controls.ControlsService;

public class ScreenService implements IService {
    private static ScreenService _instance = null;

    public static ScreenService getInstance() {
        if (_instance == null)
            _instance = new ScreenService();

        return _instance;
    }
}
