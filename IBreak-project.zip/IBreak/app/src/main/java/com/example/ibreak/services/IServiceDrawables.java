package com.example.ibreak.services;

import android.graphics.Canvas;

public interface IServiceDrawables extends IService {
    void draw(Canvas canvas);
    void update(float delta);
}
