package com.example.ibreak.services.globals;

public enum GameStates {
    READY,
    IN_ACTION,
    PAUSED,
    GAME_DEAD,
    GAME_WIN,
}
