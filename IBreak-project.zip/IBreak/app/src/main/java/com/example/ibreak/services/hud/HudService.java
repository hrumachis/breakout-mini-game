package com.example.ibreak.services.hud;

import android.content.res.Resources;
import android.graphics.Canvas;

import com.example.ibreak.modules.entity.IEntity;
import com.example.ibreak.modules.hud.Hud;
import com.example.ibreak.modules.hud.HudFactory;
import com.example.ibreak.modules.hud.IHud;
import com.example.ibreak.modules.screen.Screen;
import com.example.ibreak.services.ServicesFactory;
import com.example.ibreak.services.globals.GameStates;
import com.example.ibreak.services.globals.IGlobalsService;
import java.util.HashMap;

public class HudService implements IHudService {
    private static HudService _instance = null;
    private Canvas _canvas = null;
    private HashMap<HudId, IHud> _obstacles = new HashMap<HudId, IHud>();

    public static IHudService getInstance() {
        if (_instance == null)
            _instance = new HudService();

        return _instance;
    }

    public HudService() {
        IGlobalsService globalsService = ServicesFactory.getGlobals();

        if (globalsService != null && globalsService.getResources() != null) {
            this.load(globalsService.getResources());
        }
    }

    // Getters
    public IHud get(HudId hudId) {
        return this._obstacles.get(hudId);
    }

    // Setters
    public void set(HudId hudId, IHud hud) {  this._obstacles.put(hudId, hud); }

    // Actions
    public void draw(Canvas canvas) {
        for (HudId hudId: HudId.values()) {
            IHud hud = this.get(hudId);

            if (hud != null) {
                hud.draw(canvas);
            }
        }
    }

    public void update(float delta) {
        if (ServicesFactory.getGlobals() != null) {
            if (ServicesFactory.getGlobals().isGameState(GameStates.GAME_DEAD)) {
                IHud shadowBgHud = this.get(HudId.SHADOW_BACKGROUND);
                IHud exitButtonHud = this.get(HudId.EXIT_BUTTON);
                IHud retryButtonHud = this.get(HudId.RETRY_BUTTON);
                IHud lostTextHud = this.get(HudId.TITLE_TEXT);


                if (shadowBgHud != null && exitButtonHud != null && retryButtonHud != null && lostTextHud != null) {
                    shadowBgHud.setVisibility(true);
                    exitButtonHud.setVisibility(true);
                    retryButtonHud.setVisibility(true);
                    lostTextHud.setText("You scored " + Integer.toString(ServicesFactory.getGlobals().getScore()) + " Points");
                    lostTextHud.setVisibility(true);

                }
            }

            if (ServicesFactory.getGlobals().isGameState(GameStates.GAME_WIN)) {
                IHud shadowBgHud = this.get(HudId.SHADOW_BACKGROUND);
                IHud lostTextHud = this.get(HudId.TITLE_TEXT);
                IHud continueButtonHud = this.get(HudId.CONTINUE_BUTTON);

                if (shadowBgHud != null && continueButtonHud != null && lostTextHud != null) {
                    shadowBgHud.setVisibility(true);
                    continueButtonHud.setVisibility(true);
                    lostTextHud.setText("You completed Level " + Integer.toString(ServicesFactory.getGlobals().getLevel()));
                    lostTextHud.setVisibility(true);
                }
            }

            // Score
            IHud scoreHud = this.get(HudId.SCORE_TEXT);

            if (scoreHud != null) {
                scoreHud.setText(Integer.toString(ServicesFactory.getGlobals().getScore()));
            }

            // Lives
            IHud livesTextHud = this.get(HudId.LIVES_TEXT);

            if (livesTextHud != null) {
                IEntity paddleEntity = ServicesFactory.getEntities().getPaddle();

                if (paddleEntity != null) {
                    livesTextHud.getTextPos().setX(paddleEntity.getPos().getX() + paddleEntity.getWidth() / 2);
                    livesTextHud.getTextPos().setY(paddleEntity.getPos().getY() + 70 * Screen.calcScale());
                    livesTextHud.setText(Integer.toString(ServicesFactory.getGlobals().getLives()));
                }
            }

            if (ServicesFactory.getControls().isTouchDown()) {
                for (HudId hudId: HudId.values()) {
                    IHud hud = this.get(hudId);

                    if (hud != null) {
                        if (hud.isInArea(ServicesFactory.getControls().getPos())) {
                            try {
                                hud.onClick();
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }
            }
        }
    }

    private void load(Resources resources) {
        for (HudId hudId: HudId.values()) {
            IHud hud = HudFactory.get(hudId);

            if (hud != null)
                this.set(hudId, hud);
        }
    }
}
