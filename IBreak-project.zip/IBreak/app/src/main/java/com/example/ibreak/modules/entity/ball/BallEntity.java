package com.example.ibreak.modules.entity.ball;

import android.graphics.Color;
import android.util.Log;

import com.example.ibreak.modules.entity.Entity;
import com.example.ibreak.modules.entity.IEntity;
import com.example.ibreak.modules.entity.paddle.IPaddleEntity;
import com.example.ibreak.modules.obstacle.IObstacle;
import com.example.ibreak.modules.position.IVector2f;
import com.example.ibreak.modules.position.Vector2f;
import com.example.ibreak.modules.screen.Screen;
import com.example.ibreak.services.ServicesFactory;
import com.example.ibreak.services.controls.IControlsService;
import com.example.ibreak.services.devop.Pointer;
import com.example.ibreak.services.devop.Pointers;
import com.example.ibreak.services.globals.GameStates;
import com.example.ibreak.services.globals.IGlobalsService;

public class BallEntity extends Entity {
    private IVector2f _velocity = new Vector2f();
    private float _radius = 0;
    private IControlsService controlsService;
    private IGlobalsService globalsService;

    public BallEntity() {
        super();

        controlsService = ServicesFactory.getControls();
        globalsService = ServicesFactory.getGlobals();
        this.getVelocity().setY(-0.99f);
        this.getVelocity().setX(-0.01f);
    }

    // Getters
    public IVector2f getVelocity() { return this._velocity; }
    public float getRadius() { return this._radius; }

    // Setter
    @Override
    public void setWidth(int width) {
        super.setWidth(width);
        this._radius = (float) this.getWidth() / 2;
    }

    // Actions
    public void update(float delta) {
        if (globalsService != null) {
            if (globalsService.isGameState(GameStates.READY)) {
                this.updatePositionReady();
            } else if (globalsService.isGameState(GameStates.IN_ACTION)) {
                IVector2f uPos = this.updatedPos(this.getPos(), this.getSpeed() * delta);
                // Check Life loose
                this.checkLifeLose(uPos);
                this.updateAngle(uPos, delta);
            }
        }
    }

    private boolean checkObstacleCollision(IObstacle obstacle, IVector2f pos, IVector2f uPos) {
        if(obstacle != null && obstacle.isVisible()) {
            float hIn = 0f, wOut = 0f;
            float wIn = 0f, hOut = 0f;
            IVector2f offset = new Vector2f();

            if (pos.getX() >= obstacle.getPos().getX() && this.getVelocity().getX() > 0) {
                wIn = pos.getX() - obstacle.getPos().getX();
            } else if (pos.getX() <= obstacle.getPos().getX() + (float) obstacle.getWidth() && this.getVelocity().getX() < 0) {
                wIn = obstacle.getPos().getX() + (float) obstacle.getWidth() - pos.getX();
            }

            if (pos.getY() >= obstacle.getPos().getY() && this.getVelocity().getY() > 0) {
                hIn = pos.getY() - obstacle.getPos().getY();
            } else if (pos.getY() <= obstacle.getPos().getY() + (float) obstacle.getHeight() && this.getVelocity().getY() < 0) {
                hIn = obstacle.getPos().getY() + (float) obstacle.getHeight() - pos.getY();
            }

            if (wIn >= 0f || hIn >= 0f) {
                offset.setX((float) Math.ceil(pos.getX() + (float) wIn * -this.getVelocity().getX()));
                offset.setY((float) Math.ceil(pos.getY() + (float) hIn * -this.getVelocity().getY()));

                // *** Devops
                if (ServicesFactory.getDevops().isDevopsOn()) {
                    Pointer pointer0 = ServicesFactory.getDevops().get(Pointers.COLLISION_OFFSET);

                    if (pointer0 != null) {
                        pointer0.getPaint().setColor(Color.WHITE);
                        pointer0.getPos().setX(offset.getX());
                        pointer0.getPos().setY(offset.getY());
                    }
                }

                if (offset.getY()  < obstacle.getPos().getY() + obstacle.getHeight() - 2 &&
                        offset.getY() > obstacle.getPos().getY() + 2) {
                    this.getVelocity().setX(-this.getVelocity().getX());
                }

                 if (offset.getX() > obstacle.getPos().getX() +2 &&
                        offset.getX() < obstacle.getPos().getX() + obstacle.getWidth() - 2) {
                    this.getVelocity().setY(-this.getVelocity().getY());
                }

                obstacle.onCollide();

                return true;
            }
        }

        return false;
    }

    private boolean calcForcePoints(IVector2f pos, IVector2f uPos) {
        IVector2f center = new Vector2f();
        IVector2f forceFVect = new Vector2f();
        IVector2f forceLPVect = new Vector2f();
        IVector2f forceRPVect = new Vector2f();

        center.setX(pos.getX() + this.getRadius());
        center.setY(pos.getY() + this.getRadius());

        forceFVect.setX(center.getX() + this.getRadius() * this.getVelocity().getX());
        forceFVect.setY(center.getY() + this.getRadius() * this.getVelocity().getY());

        // Force left point
        if (this.getVelocity().getX() > 0 && this.getVelocity().getY() > 0) {
            forceLPVect.setX(center.getX() + this.getRadius() * (1 - this.getVelocity().getX()));
            forceLPVect.setY(center.getY() + this.getRadius() * (-1 + this.getVelocity().getY()));
            forceRPVect.setX(center.getX() + this.getRadius() * (-1 + this.getVelocity().getX()));
            forceRPVect.setY(center.getY() + this.getRadius() * (1 - this.getVelocity().getY()));
        } else if (this.getVelocity().getX() > 0 && this.getVelocity().getY() < 0) {
            forceLPVect.setX(center.getX() + this.getRadius() * (-1 + this.getVelocity().getX()));
            forceLPVect.setY(center.getY() + this.getRadius() * (-1 - this.getVelocity().getY()));
            forceRPVect.setX(center.getX() + this.getRadius() * (1 - this.getVelocity().getX()));
            forceRPVect.setY(center.getY() + this.getRadius() * (1 + this.getVelocity().getY()));
        } else if (this.getVelocity().getX() < 0 && this.getVelocity().getY() < 0) {
            forceLPVect.setX(center.getX() + this.getRadius() * (-1 - this.getVelocity().getX()));
            forceLPVect.setY(center.getY() + this.getRadius() * (1 + this.getVelocity().getY()));
            forceRPVect.setX(center.getX() + this.getRadius() * (1 + this.getVelocity().getX()));
            forceRPVect.setY(center.getY() + this.getRadius() * (-1 - this.getVelocity().getY()));
        } else if (this.getVelocity().getX() < 0 && this.getVelocity().getY() > 0) {
            forceLPVect.setX(center.getX() + this.getRadius() * (1 + this.getVelocity().getX()));
            forceLPVect.setY(center.getY() + this.getRadius() * (1 - this.getVelocity().getY()));
            forceRPVect.setX(center.getX() + this.getRadius() * (-1 - this.getVelocity().getX()));
            forceRPVect.setY(center.getY() + this.getRadius() * (-1 + this.getVelocity().getY()));
        }

        // *** Devops
        if (ServicesFactory.getDevops().isDevopsOn()) {
            Pointer pointer0 = ServicesFactory.getDevops().get(Pointers.BALL_POINTER0);

            if (pointer0 != null) {
                pointer0.getPos().setX(forceFVect.getX());
                pointer0.getPos().setY(forceFVect.getY());
            }

            Pointer pointer1 = ServicesFactory.getDevops().get(Pointers.BALL_POINTER1);

            if (pointer1 != null) {
                pointer1.getPaint().setColor(Color.CYAN);
                pointer1.getPos().setX(forceLPVect.getX());
                pointer1.getPos().setY(forceLPVect.getY());
            }

            Pointer pointer2 = ServicesFactory.getDevops().get(Pointers.BALL_POINTER2);

            if (pointer2 != null) {
                pointer2.getPaint().setColor(Color.CYAN);
                pointer2.getPos().setX(forceRPVect.getX());
                pointer2.getPos().setY(forceRPVect.getY());
            }
        }

        // Check points collision with bricks and paddle
        if (this.checkObstacleCollision(ServicesFactory.getObstacles().getByObserverPos(forceLPVect.getX(), forceLPVect.getY()), forceLPVect, uPos) ||
            this.checkObstacleCollision(ServicesFactory.getObstacles().getByObserverPos(forceRPVect.getX(), forceRPVect.getY()), forceRPVect, uPos) ||
            this.checkObstacleCollision(ServicesFactory.getObstacles().getByObserverPos(forceFVect.getX(), forceFVect.getY()), forceFVect, uPos) ||
            this.checkPaddleCollision(forceLPVect, uPos) ||
            this.checkPaddleCollision(forceRPVect, uPos) ||
            this.checkPaddleCollision(forceFVect, uPos)) {
            return true;
        }

        return false;
    }

    private boolean checkPaddleCollision(IVector2f pos, IVector2f uPos) {
        if (this.getVelocity().getY() > 0) {
            IEntity paddleEntity = ServicesFactory.getEntities().getPaddle();

            if (paddleEntity != null) {
                float px0 = paddleEntity.getPos().getX();
                float px1 = px0 + paddleEntity.getWidth();
                float py0 = paddleEntity.getPos().getY();
                float py1 = py0 + paddleEntity.getHeight()/2;

                if (px0 <= pos.getX() && px1 >= pos.getX()) {
                    if (py0 <= pos.getY() && py1 >= pos.getY()) {
                        float width = (float) paddleEntity.getWidth() / 2;
                        float forceX1 = (1 / (width + width / 2)) * (pos.getX() - px0 - width);
                        float forceY1 = -(1 - Math.abs(forceX1));

                        this.getVelocity().setX(forceX1);
                        this.getVelocity().setY(forceY1);
                        this.incSpeed();
                        return true;
                    }
                }
            }
        }

        return false;
    }

    private void checkLifeLose(IVector2f pos) {
        if (pos.getY() + this.getHeight() >= Screen.getHeight()) {
            ServicesFactory.getGlobals().decreaseLives(1);
        }
    }

    private boolean checkEdgesCollision(IVector2f pos, IVector2f uPos) {
        boolean collided = false;

        if (pos.getX() < 0) {
            uPos.setX(0);
            this.getVelocity().setX(-this.getVelocity().getX());
            collided = true;
        } else if (pos.getX() + this.getWidth() > Screen.getWidth()) {
            uPos.setX(Screen.getWidth()-this.getWidth());
            this.getVelocity().setX(-this.getVelocity().getX());
            collided = true;
        }

        if (pos.getY() < 0) {
            uPos.setY(0);
            this.getVelocity().setY(-this.getVelocity().getY());
            collided = true;
        } else if (pos.getY() + this.getHeight() > Screen.getHeight()) {
            uPos.setY(Screen.getHeight()-this.getHeight());
            this.getVelocity().setY(-this.getVelocity().getY());
            collided = true;
        }

        if (collided) {
            this.incSpeed();
        }

        return collided;
    }

    private void updateAngle(IVector2f uPos, float delta) {
        boolean collided = this.calcForcePoints(uPos, uPos);

        if (!collided) {
            this.checkEdgesCollision(uPos, uPos);
        }

        this.getPos().setX(uPos.getX());
        this.getPos().setY(uPos.getY());
    }

    private IVector2f updatedPos(IVector2f pos, float speed) {
        IVector2f uPos = new Vector2f();
        float x = pos.getX();
        float y = pos.getY();

        float velocityX = speed * this.getVelocity().getX();
        float velocityY = speed * this.getVelocity().getY();

        x += velocityX;
        y += velocityY;

        uPos.setX(x);
        uPos.setY(y);

        return uPos;
    }

    private void updatePositionReady() {
        IEntity paddleEntity = ServicesFactory.getEntities().getPaddle();

        this.getPos().setY(Screen.getHeight() - this.getHeight() - paddleEntity.getHeight() - 90);
        this.getPos().setX(paddleEntity.getPos().getX() + paddleEntity.getWidth() / 2 - this.getWidth() / 2);
    }
}
