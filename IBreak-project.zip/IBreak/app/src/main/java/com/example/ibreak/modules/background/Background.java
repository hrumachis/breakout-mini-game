package com.example.ibreak.modules.background;

import android.graphics.Canvas;

import com.example.ibreak.modules.position.IVector2f;
import com.example.ibreak.modules.position.Vector2f;
import com.example.ibreak.modules.screen.Screen;
import com.example.ibreak.modules.texture.ITexture;

public class Background implements IBackground {
    private IVector2f _position = new Vector2f();
    private ITexture _texture = null;
    private int _width = Screen.getWidth();
    private int _height = Screen.getHeight();

    // Getters
    public IVector2f getPos() { return this._position; }
    public ITexture getTexture() { return this._texture; }
    public int getWidth() { return this._width; }
    public int getHeight() { return this._height; }

    // Setters
    public IBackground setTexture(ITexture texture) { this._texture = texture; return this; }

    // Actions
    public void draw(Canvas canvas) {
        this.getTexture().draw(canvas);
    }

    public void resize() {
        this.getTexture().resize(this.getWidth(), this.getHeight());
    }
}
