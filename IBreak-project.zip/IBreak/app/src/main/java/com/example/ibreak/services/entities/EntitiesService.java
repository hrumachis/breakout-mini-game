package com.example.ibreak.services.entities;

import android.content.res.Resources;
import android.graphics.Canvas;
import com.example.ibreak.modules.entity.Entity;
import com.example.ibreak.modules.entity.IEntity;
import com.example.ibreak.modules.entity.ball.BallEntity;
import com.example.ibreak.modules.entity.paddle.IPaddleEntity;
import com.example.ibreak.modules.entity.paddle.PaddleEntity;
import com.example.ibreak.modules.screen.Screen;
import com.example.ibreak.services.globals.IGlobalsService;
import com.example.ibreak.services.ServicesFactory;
import com.example.ibreak.services.textures.TextureBuilder;
import com.example.ibreak.services.textures.Textures;

import java.util.HashMap;

public class EntitiesService implements IEntitiesService {
    private static IEntitiesService _instance = null;
    private IEntity _paddle = null;
    private IEntity _ball = null;

    public static IEntitiesService getInstance() {
        if (_instance == null)
            _instance = new EntitiesService();

        return _instance;
    }

    public EntitiesService() {
        IGlobalsService globalsService = ServicesFactory.getGlobals();

        if (globalsService != null && globalsService.getResources() != null) {
            this.load(globalsService.getResources());
        }
    }

    // Getters
    public IEntity getPaddle() {
        return this._paddle;
    }
    public IEntity getBall() {
        return this._ball;
    }

    // Setters
    public void setPaddle(IEntity entity) {  this._paddle = entity; }
    public void setBall(IEntity entity) {  this._ball = entity; }

    // Actions
    public void restart() {
        IEntity paddle = this.getPaddle();
        IEntity ball = this.getBall();

        ball.setSpeed(7);
        paddle.getPos().setX(Screen.getWidth() / 2 - paddle.getWidth() / 2);
        paddle.getPos().setY(Screen.getHeight() - paddle.getHeight() - 100);
    }

    public void draw(Canvas canvas) {
        if (this.getPaddle() != null)
            this.getPaddle().draw(canvas);

        if (this.getBall() != null)
            this.getBall().draw(canvas);
    }

    public void update(float delta) {
        if (this.getPaddle() != null)
            this.getPaddle().update(delta);

        if (this.getBall() != null)
            this.getBall().update(delta);
    }

    private void load(Resources resources) {
        this.loadPaddle(resources);
        this.loadBall(resources);
    }

    private void loadBall(Resources resources) {
        IEntity paddle = this.getPaddle();
        IEntity entity = new BallEntity();
        entity.setTexture(TextureBuilder.build(resources, Textures.BALL1));
        entity.setWidth(64);
        entity.setHeight(64);
        entity.setSpeed(7);

        entity.resize(0.7f);
        entity.getPos().setX(Screen.getWidth() / 2 - entity.getWidth() / 2);
        entity.getPos().setY(Screen.getHeight() - entity.getHeight() - paddle.getHeight() - 90);

        this.setBall(entity);
    }

    private void loadPaddle(Resources resources) {
        IEntity entity = new PaddleEntity();
        entity.setTexture(TextureBuilder.build(resources, Textures.PADDLE0));
        entity.setWidth(137);
        entity.setHeight(24);
        entity.setSpeed(100);

        entity.resize(2f);
        entity.getPos().setX(Screen.getWidth() / 2 - entity.getWidth() / 2);
        entity.getPos().setY(Screen.getHeight() - entity.getHeight() - 100);

        this.setPaddle(entity);
    }
}
