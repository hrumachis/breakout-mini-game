package com.example.ibreak.modules.utils;

import java.sql.Timestamp;

public class DateUtil {
    public final static long getTimestamp() {
        return new Timestamp(System.currentTimeMillis()).getTime();
    }
}
