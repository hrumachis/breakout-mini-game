package com.example.ibreak.services.devop;

import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Color;
import android.util.Log;

import com.example.ibreak.Constants;
import com.example.ibreak.modules.background.Backgrounds;
import com.example.ibreak.modules.background.IBackground;
import com.example.ibreak.modules.obstacle.IObstacle;
import com.example.ibreak.modules.obstacle.Obstacle;
import com.example.ibreak.modules.screen.Screen;
import com.example.ibreak.services.ServicesFactory;
import com.example.ibreak.services.globals.IGlobalsService;
import com.example.ibreak.services.obstacles.ObstaclesService;
import com.example.ibreak.services.textures.TextureBuilder;
import com.example.ibreak.services.textures.Textures;

import java.util.HashMap;

public class DevopService {
    private boolean devopsOn = false;
    private static DevopService _instance = null;
    private HashMap<Pointers, Pointer> _pointers = new HashMap<Pointers, Pointer>();

    public static DevopService getInstance() {
        if (_instance == null)
            _instance = new DevopService();

        return _instance;
    }

    public DevopService() {
        if (this.isDevopsOn())
            this.load();
    }

    // Getters
    public Pointer get(Pointers pointerId) {
        return this._pointers.get(pointerId);
    }

    // Setters
    public void set(Pointers pointerId, Pointer pointer) {  this._pointers.put(pointerId, pointer); }

    // Booleans
    public boolean isDevopsOn() { return this.devopsOn == true; }

    // Actions
    public void draw(Canvas canvas) {
        if(this.isDevopsOn()) {
            for (Pointers pointerId: Pointers.values()) {
                Pointer pointer = this.get(pointerId);

                if (pointer != null) {
                    pointer.draw(canvas);
                }
            }
        }
    }

    public void update(float delta) {
        if(this.isDevopsOn()) {
            for (Pointers pointerId: Pointers.values()) {
                Pointer pointer = this.get(pointerId);

                if (pointer != null) {
                    pointer.update(delta);
                }
            }
        }
    }

    private void load() {
        for (Pointers pointerId: Pointers.values()) {
            Pointer pointer = new Pointer();
            pointer.getPaint().setColor(Color.BLUE);

            this.set(pointerId, pointer);
        }
    }
}
