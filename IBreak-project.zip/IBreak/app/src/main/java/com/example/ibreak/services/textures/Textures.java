package com.example.ibreak.services.textures;

public enum Textures {
    BG0,
    BG1,
    BALL0,
    BALL1,
    BRICK0,
    BRICK1,
    BRICK2,
    PADDLE0,
}
