package com.example.ibreak;

public class Constants {
    public static final int BRICKS_ROWS = 6; // 6
    public static final int BRICKS_COLUMNS = 14; // 14
    public static final int LIVES_INIT = 3;
}
