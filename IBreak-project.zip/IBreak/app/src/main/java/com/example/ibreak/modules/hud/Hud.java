package com.example.ibreak.modules.hud;

import android.graphics.Canvas;
import android.graphics.Paint;

import com.example.ibreak.modules.position.IVector2f;
import com.example.ibreak.modules.position.Vector2f;
import com.example.ibreak.services.controls.ControlsService;
import com.example.ibreak.services.globals.GlobalsService;

import java.util.concurrent.Callable;

public class Hud implements IHud {
    private Paint _paintBg = new Paint();
    private Paint _textBg = new Paint();
    private int _width = 0;
    private int _height = 0;
    private int _padding = 0;
    private boolean _background = false;
    private boolean _visable = false;
    private IVector2f _bgPos = new Vector2f();
    private IVector2f _textPos = new Vector2f();
    private String _text = "";
    private boolean _clickable = false;
    private Callable _clickCallback = null;

    // Getters
    public Paint getBgPaint() { return this._paintBg; }
    public Paint getTextPaint() { return _textBg; }
    public IVector2f getBgPos() { return this._bgPos; }
    public IVector2f getTextPos() { return this._textPos; }
    public int getWidth() { return this._width; }
    public int getHeight() { return this._height; }
    public int getPadding() { return this._padding; }
    public String getText() { return this._text; }

    // Setters
    public void setWidth(int width) { this._width = width; }
    public void setHeight(int height) { this._height = height; }
    public void setPadding(int padding) { this._padding = padding; }
    public void useBackground(boolean use) { this._background = use; }
    public void setVisibility(boolean visibility) { this._visable = visibility; }
    public void setText(String text) { this._text = text; }
    public void setClickable(boolean clickable) { this._clickable = clickable; }
    public void setCallback(Callable callback) { this._clickCallback = callback; }

    // Booleans
    public boolean haveBackground(){ return this._background; }
    public boolean haveText() { return this._text.length() > 0; }
    public boolean isVisible(){ return this._visable == true; }
    public boolean isClickable() { return this._clickable == true; }
    public boolean isInArea(IVector2f pos) {
        if (haveBackground() && isVisible() &&
            pos.getX() >= this.getBgPos().getX() &&
            pos.getX() <= this.getBgPos().getX() + this.getWidth() &&
            pos.getY() >= this.getBgPos().getY() &&
            pos.getY() <= this.getBgPos().getY() + this.getHeight()) {
            return true;
        }

        return false;
    }

    // Events
    public void onClick() throws Exception {
        ControlsService.getInstance().setButtonClicked(true);

        if (this._clickCallback != null) {
            try {
                this._clickCallback.call();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    // Actions
    public void draw(Canvas canvas) {
        if (this.isVisible()) {
            if (this.haveBackground()) {
                this.drawBackground(canvas);
            }

            if (this.haveText()) {
                this.drawText(canvas);
            }
        }
    }

    private void drawText(Canvas canvas) {
        int x = (int) this.getTextPos().getX() + this.getPadding();
        int y = (int) this.getTextPos().getY() + this.getPadding();

        canvas.drawText(this.getText(), x, y, this.getTextPaint());
    }

    private void drawBackground(Canvas canvas) {
        int x0 = (int) this.getBgPos().getX() + this.getPadding();
        int y0 = (int) this.getBgPos().getY() + this.getPadding();
        int x1 = x0 + this.getWidth() - this.getPadding() * 2;
        int y1 = y0 + this.getHeight() - this.getPadding() * 2;

        canvas.drawRect(x0, y0, x1, y1, this.getBgPaint());
    }
}
