package com.example.ibreak.services.obstacles;

import com.example.ibreak.modules.obstacle.IObstacle;
import com.example.ibreak.services.IServiceDrawables;

public interface IObstaclesService extends IServiceDrawables {
    // Getters
    IObstacle getByObserverPos(float x, float y);

    // Actions
    void decreaseObstaclesCount();
    void restart();
}
