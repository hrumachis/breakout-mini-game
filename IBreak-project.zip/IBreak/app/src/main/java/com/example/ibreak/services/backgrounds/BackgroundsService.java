package com.example.ibreak.services.backgrounds;

import android.content.res.Resources;
import android.graphics.Canvas;

import com.example.ibreak.modules.background.Background;
import com.example.ibreak.modules.background.Backgrounds;
import com.example.ibreak.modules.background.IBackground;
import com.example.ibreak.services.IServiceDrawables;
import com.example.ibreak.services.globals.IGlobalsService;
import com.example.ibreak.services.ServicesFactory;
import com.example.ibreak.services.textures.TextureBuilder;
import com.example.ibreak.services.textures.Textures;

import java.util.HashMap;

public class BackgroundsService implements IServiceDrawables {
    private static BackgroundsService _instance = null;
    private HashMap<Backgrounds, IBackground> _backgrounds = new HashMap<Backgrounds, IBackground>();

    public static BackgroundsService getInstance() {
        if (_instance == null)
            _instance = new BackgroundsService();

        return _instance;
    }

    public BackgroundsService() {
        IGlobalsService globalsService = ServicesFactory.getGlobals();

        if (globalsService != null && globalsService.getResources() != null) {
            this.load(globalsService.getResources());
        }
    }

    // Getters
    public IBackground get(Backgrounds backgroundName) { return this._backgrounds.get(backgroundName); }

    // Setters
    public void set(Backgrounds backgroundName, IBackground background) {  this._backgrounds.put(backgroundName, background); }

    // Actions
    public void draw(Canvas canvas) {
        for (Backgrounds backgroundName: Backgrounds.values()) {
            IBackground background = this.get(backgroundName);

            if (background != null) {
                background.draw(canvas);
            }
        }
    }

    public void update(float delta) {

    }

    private void load(Resources resources) {
        for (Backgrounds backgroundName: Backgrounds.values()) {
            IBackground background = new Background()
                .setTexture(TextureBuilder.build(resources, Textures.BG1));

            background.resize();

            this.set(backgroundName, background);
        }
    }
}
