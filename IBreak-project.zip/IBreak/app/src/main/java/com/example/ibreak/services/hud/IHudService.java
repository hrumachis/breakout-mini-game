package com.example.ibreak.services.hud;

import com.example.ibreak.modules.hud.IHud;
import com.example.ibreak.services.IServiceDrawables;

public interface IHudService extends IServiceDrawables {
    IHud get(HudId hudId);
}
