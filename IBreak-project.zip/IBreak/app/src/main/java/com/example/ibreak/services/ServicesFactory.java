package com.example.ibreak.services;

import com.example.ibreak.services.backgrounds.BackgroundsService;
import com.example.ibreak.services.controls.ControlsService;
import com.example.ibreak.services.controls.IControlsService;
import com.example.ibreak.services.devop.DevopService;
import com.example.ibreak.services.entities.EntitiesService;
import com.example.ibreak.services.entities.IEntitiesService;
import com.example.ibreak.services.globals.GlobalsService;
import com.example.ibreak.services.globals.IGlobalsService;
import com.example.ibreak.services.hud.HudService;
import com.example.ibreak.services.hud.IHudService;
import com.example.ibreak.services.obstacles.IObstaclesService;
import com.example.ibreak.services.obstacles.ObstaclesService;
import com.example.ibreak.services.screen.ScreenService;

public class ServicesFactory {
    public static final IService get(Services serviceId) {
        switch (serviceId) {
            case BACKGROUNDS: return BackgroundsService.getInstance();
            case GLOBALS: return GlobalsService.getInstance();
            case ENTITIES: return EntitiesService.getInstance();
            case OBSTACLES: return ObstaclesService.getInstance();
            case CONTROLS: return ControlsService.getInstance();
            case SCREEN: return ScreenService.getInstance();

            default: return null;
        }
    }

    public static final IServiceDrawables getDrawables(Services serviceId) {
        switch (serviceId) {
            case BACKGROUNDS: return BackgroundsService.getInstance();
            case ENTITIES: return EntitiesService.getInstance();
            case OBSTACLES: return ObstaclesService.getInstance();
            case HUD: return HudService.getInstance();
            default: return null;
        }
    }

    public static final IHudService getHud() {
        return HudService.getInstance();
    }
    public static final IControlsService getControls() {
        return ControlsService.getInstance();
    }
    public static final IEntitiesService getEntities() {
        return EntitiesService.getInstance();
    }
    public static final IObstaclesService getObstacles() {
        return ObstaclesService.getInstance();
    }
    public static final IGlobalsService getGlobals() { return GlobalsService.getInstance(); }
    public static final DevopService getDevops() { return DevopService.getInstance(); }
}
