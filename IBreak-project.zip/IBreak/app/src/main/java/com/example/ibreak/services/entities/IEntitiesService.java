package com.example.ibreak.services.entities;

import com.example.ibreak.modules.entity.IEntity;
import com.example.ibreak.services.IServiceDrawables;

public interface IEntitiesService extends IServiceDrawables {
    // Getters
    IEntity getPaddle();
    IEntity getBall();

    // Setters
    void setPaddle(IEntity entity);
    void setBall(IEntity entity);

    // Actions
    void restart();
}
