package com.example.ibreak.modules.hud.builders;

import android.graphics.Color;
import android.graphics.Paint;
import android.renderscript.ScriptC;

import com.example.ibreak.modules.hud.Hud;
import com.example.ibreak.modules.hud.IHud;
import com.example.ibreak.modules.screen.Screen;

public class ScoreHudBuilder {
    public static final IHud build() {
        IHud hud = new Hud();
        hud.getTextPos().setX(((int) Screen.getWidth() / 2));
        hud.getTextPos().setY((int) (60 * Screen.calcScale()));
        hud.getTextPaint().setColor(Color.argb(180, 245, 236, 206));
        hud.getTextPaint().setTextSize((int) (60 * Screen.calcScale()));
        hud.getTextPaint().setTextAlign(Paint.Align.CENTER);
        hud.getTextPaint().setShadowLayer(20f, 0f, 0f, Color.argb(200, 245, 236, 206));
        hud.setText("0");
        hud.setVisibility(true);

        return hud;
    }
}
