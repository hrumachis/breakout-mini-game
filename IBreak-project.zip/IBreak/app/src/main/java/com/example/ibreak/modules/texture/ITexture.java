package com.example.ibreak.modules.texture;

import android.graphics.Bitmap;
import android.graphics.Canvas;

public interface ITexture {
    Bitmap getImage();

    // Setters
    Texture setImage(Bitmap image);

    // Actions
    void draw(Canvas canvas);
    void draw(Canvas canvas, int x, int y);
    void resize(int widthNew, int heightNew);
}
