package com.example.ibreak.services;

public enum Services {
    GLOBALS,
    BACKGROUNDS,
    CONTROLS,
    ENTITIES,
    OBSTACLES,
    SCREEN,
    HUD,
}
