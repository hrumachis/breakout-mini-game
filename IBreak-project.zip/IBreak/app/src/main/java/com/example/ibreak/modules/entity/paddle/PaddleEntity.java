package com.example.ibreak.modules.entity.paddle;

import com.example.ibreak.modules.entity.Entity;
import com.example.ibreak.modules.screen.Screen;
import com.example.ibreak.services.ServicesFactory;
import com.example.ibreak.services.controls.IControlsService;
import com.example.ibreak.services.globals.GameStates;

public class PaddleEntity extends Entity {
    private IControlsService controlsService;

    public PaddleEntity() {
        super();

        controlsService = ServicesFactory.getControls();
    }

    // Actions
    public void update(float delta) {
        if (ServicesFactory.getGlobals() != null) {
            if (ServicesFactory.getGlobals().isGameState(GameStates.IN_ACTION) || ServicesFactory.getGlobals().isGameState(GameStates.READY)) {
                this.updatePosition(delta);
            }
        }
    }

    private void updatePosition(float delta) {
        if (controlsService != null && controlsService.isTouchDown() && !controlsService.isButtonClicked()) {
            float x = this.getPos().getX();
            float xTarget = controlsService.getPos().getX() - this.getWidth() / 2;
            float diff = xTarget - x;
            float velocity = this.getSpeed() * delta;

            if (diff < 0) {
                if (diff > -velocity) {
                    x = xTarget;
                } else {
                    x -= velocity;
                }
            } else if (diff > 0) {
                if (diff < velocity) {
                    x = xTarget;
                } else {
                    x += velocity;
                }
            }

            if (x < 0) {
                x = 0;
            } else if (x + this.getWidth() > Screen.getWidth()) {
                x = Screen.getWidth() - this.getWidth();
            }

            this.getPos().setX(x);
        }
    }
}
