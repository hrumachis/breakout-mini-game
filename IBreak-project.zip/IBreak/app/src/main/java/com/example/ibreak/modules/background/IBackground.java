package com.example.ibreak.modules.background;

import android.graphics.Canvas;

import com.example.ibreak.modules.position.IVector2f;
import com.example.ibreak.modules.texture.ITexture;

public interface IBackground {
    // Getters
    IVector2f getPos();
    ITexture getTexture();
    int getWidth();
    int getHeight();

    // Setters
    IBackground setTexture(ITexture texture);

    // Actions
    void draw(Canvas canvas);
    void resize();
}
