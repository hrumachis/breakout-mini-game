package com.example.ibreak.modules.hud.builders;

import android.graphics.Color;

import com.example.ibreak.modules.hud.Hud;
import com.example.ibreak.modules.hud.IHud;
import com.example.ibreak.modules.screen.Screen;

public class ShadowBackgroundHudBuilder {
    public static final IHud build() {
        IHud hud = new Hud();
        hud.setWidth(Screen.getWidth());
        hud.setHeight(Screen.getHeight());
        hud.getBgPaint().setColor(Color.argb(200, 20, 20, 20));
        hud.setPadding((int) (50 * Screen.calcScale()));
        hud.useBackground(true);

        return hud;
    }
}
