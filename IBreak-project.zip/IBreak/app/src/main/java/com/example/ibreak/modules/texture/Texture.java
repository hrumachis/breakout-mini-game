package com.example.ibreak.modules.texture;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;

import com.example.ibreak.R;

public class Texture implements ITexture {
    private Bitmap _image;

    // Getters
    public Bitmap getImage() { return this._image; }

    // Setters
    public Texture setImage(Bitmap image) { this._image = image; return this; }

    // Actions
    public void draw(Canvas canvas, int x, int y) { canvas.drawBitmap(this.getImage(), x, y, null); }
    public void draw(Canvas canvas) { canvas.drawBitmap(this.getImage(), 0, 0, null); }


    public void resize(int widthNew, int heightNew) {
        int width = this.getImage().getWidth();
        int height = this.getImage().getHeight();
        float scaleWidth = ((float) widthNew) / width;
        float scaleHeight = ((float) heightNew) / height;

        Matrix matrix = new Matrix();
        matrix.postScale(scaleWidth, scaleHeight);
        Bitmap resizedBitmap = Bitmap.createBitmap(this.getImage(), 0, 0, width, height, matrix, false);
        this.getImage().recycle();
        this.setImage(resizedBitmap);
    }
}
