package com.example.ibreak.modules.hud;

import com.example.ibreak.modules.hud.builders.ContinueButtonHudBuilder;
import com.example.ibreak.modules.hud.builders.ExitButtonHudBuilder;
import com.example.ibreak.modules.hud.builders.LivesTextHudBuilder;
import com.example.ibreak.modules.hud.builders.TitleHudBuilder;
import com.example.ibreak.modules.hud.builders.RetryButtonHudBuilder;
import com.example.ibreak.modules.hud.builders.ScoreHudBuilder;
import com.example.ibreak.modules.hud.builders.ShadowBackgroundHudBuilder;
import com.example.ibreak.services.hud.HudId;

public class HudFactory {
    public static final IHud get(HudId hudId) {
        switch (hudId) {
            case TITLE_TEXT: return TitleHudBuilder.build();
            case EXIT_BUTTON: return ExitButtonHudBuilder.build();
            case RETRY_BUTTON: return RetryButtonHudBuilder.build();
            case CONTINUE_BUTTON: return ContinueButtonHudBuilder.build();
            case SCORE_TEXT: return ScoreHudBuilder.build();
            case SHADOW_BACKGROUND: return ShadowBackgroundHudBuilder.build();
            case LIVES_TEXT: return LivesTextHudBuilder.build();
            default: return null;
        }
    }
}
