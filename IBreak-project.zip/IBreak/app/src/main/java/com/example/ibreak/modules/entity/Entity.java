package com.example.ibreak.modules.entity;

import android.graphics.Canvas;

import com.example.ibreak.modules.position.IVector2f;
import com.example.ibreak.modules.position.Vector2f;
import com.example.ibreak.modules.screen.Screen;
import com.example.ibreak.modules.texture.ITexture;

public class Entity implements IEntity {
    private IVector2f _position = new Vector2f();
    private ITexture _texture = null;
    private int _width = 1;
    private int _height = 1;
    private float _speed = 10;

    public Entity() {

    }

    // Getters
    public IVector2f getPos() { return this._position; }
    public ITexture getTexture() { return this._texture; }
    public int getWidth() { return this._width; }
    public int getHeight() { return this._height; }
    public float getSpeed() { return this._speed; }

    // Setters
    public void setTexture(ITexture texture) { this._texture = texture; }
    public void setWidth(int width) { this._width = (int) Math.floor(width * Screen.calcScale()); }
    public void setHeight(int height) { this._height = (int) Math.floor(height * Screen.calcScale()); }
    public void setSpeed(float speed) { this._speed = speed * Screen.calcScale(); }


    // Actions
    public void draw(Canvas canvas) {
        this.getTexture().draw(canvas, (int) this.getPos().getX(), (int) this.getPos().getY());
    }

    public void incSpeed() {
        this.setSpeed(this.getSpeed() + 0.05f);
    }

    public void update(float delta) {}

    public void resize() {
        if (this.getWidth() > 0 && this.getHeight() > 0) {
            this.getTexture().resize(this.getWidth(), this.getHeight());
        }
    }

    public void resize(float scale) {
        if (this.getWidth() > 0 && this.getHeight() > 0) {
            this.setWidth((int) (this.getWidth() * scale));
            this.setHeight((int) (this.getHeight() * scale));
            this.resize();
        }
    }
}
