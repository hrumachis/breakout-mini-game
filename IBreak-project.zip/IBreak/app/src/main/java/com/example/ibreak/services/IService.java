package com.example.ibreak.services;

public interface IService {
}
