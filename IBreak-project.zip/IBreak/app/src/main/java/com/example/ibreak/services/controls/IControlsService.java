package com.example.ibreak.services.controls;

import com.example.ibreak.modules.position.IVector2f;
import com.example.ibreak.services.IService;

public interface IControlsService extends IService {
    // Getters
    IVector2f getPos();

    // Setters
    void setButtonClicked(boolean clicked);
    void setInitTouch(boolean initTouch);

    // Booleans
    boolean isSwingUp();
    boolean isTouchDown();
    boolean isButtonClicked();
    boolean isInitTouched();
}
