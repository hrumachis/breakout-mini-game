package com.example.ibreak.services.textures;
import android.content.res.Resources;
import android.graphics.BitmapFactory;

import com.example.ibreak.R;
import com.example.ibreak.modules.texture.ITexture;
import com.example.ibreak.modules.texture.Texture;
import java.util.HashMap;

public class TexturesService {
    private HashMap<Textures, ITexture> _textures = new HashMap<Textures, ITexture>();

    public TexturesService(Resources resources) {
        this.load(resources);
    }

    // Getters
    public ITexture get(Textures textureName) {
         return this._textures.get(textureName);
    }

    // Setters
    public void set(Textures textureName, ITexture texture) {
        this._textures.put(textureName, texture);
    }

    // Actions
    private void load(Resources resources) {
        for (Textures textureName: Textures.values()) {
            ITexture texture = new Texture()
                .setImage(BitmapFactory.decodeResource(resources, TextureSelector.get(textureName)));

            this.set(textureName, texture);
        }
    }
}
