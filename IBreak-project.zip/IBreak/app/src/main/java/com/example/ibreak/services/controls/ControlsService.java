package com.example.ibreak.services.controls;

import android.view.MotionEvent;
import android.view.View;
import com.example.ibreak.modules.position.IVector2f;
import com.example.ibreak.modules.position.Vector2f;
import com.example.ibreak.modules.screen.Screen;
import com.example.ibreak.modules.utils.DateUtil;
import com.example.ibreak.services.globals.GameStates;
import com.example.ibreak.services.globals.GlobalsService;
import com.example.ibreak.services.globals.IGlobalsService;
import com.example.ibreak.services.ServicesFactory;

public class ControlsService implements IControlsService {
    private static IControlsService _instance = null;
    private IVector2f _position = new Vector2f();
    private IVector2f _positionStart = new Vector2f();
    private boolean _swingUp = false;
    private boolean _touchDown = false;
    private boolean _buttonClicked = false;
    private boolean _initTouch = false;

    public static IControlsService getInstance() {
        if (_instance == null)
            _instance = new ControlsService();

        return _instance;
    }

    public ControlsService() {
        IGlobalsService globalsService = ServicesFactory.getGlobals();

        if (globalsService != null && globalsService.getResources() != null && globalsService.getGameView() != null) {
            globalsService.getGameView().setOnTouchListener(this.onMoveEvent());;
        }
    }

    // Getters
    public IVector2f getPos() { return this._position; }
    private IVector2f getPosStart() { return this._positionStart; }

    // Setters
    public void setButtonClicked(boolean clicked) { this._buttonClicked = clicked; }

    // Booleans
    public boolean isSwingUp() { return this._swingUp; }
    public boolean isTouchDown() { return this._touchDown; }
    public boolean isButtonClicked() { return this._buttonClicked; }
    public boolean isInitTouched() { return this._initTouch; }

    // Events
    public View.OnTouchListener onMoveEvent() {
        final ControlsService controlsService = this;

        return new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                IVector2f pos = controlsService.getPos();
                IVector2f posStart = controlsService.getPosStart();

                pos.setX(motionEvent.getX());
                pos.setY(motionEvent.getY());

                switch (motionEvent.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        controlsService._touchDown = true;
                        posStart.setY(motionEvent.getY());
                        break;

                    case MotionEvent.ACTION_MOVE:
                        //controlsService._moveTimestamp = DateUtil.getTimestamp();
                        break;

                    case MotionEvent.ACTION_UP:
                        controlsService._touchDown = false;
                        controlsService._swingUp = false;
                        controlsService._buttonClicked = false;

                        if (!controlsService.isInitTouched()) {
                            controlsService._initTouch = true;
                            if (GlobalsService.getInstance().isGameState(GameStates.READY))
                                GlobalsService.getInstance().setGameState(GameStates.IN_ACTION);
                        }

                        break;
                }

                if (pos.getY() < posStart.getY() - 150) {
                    controlsService._swingUp = true;
                }

                return true;
            }
        };
    }
}
