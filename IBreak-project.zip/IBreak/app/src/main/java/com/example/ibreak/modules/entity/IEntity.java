package com.example.ibreak.modules.entity;

import android.graphics.Canvas;

import com.example.ibreak.modules.position.IVector2f;
import com.example.ibreak.modules.texture.ITexture;

public interface IEntity {
    // Getters
    IVector2f getPos();
    int getWidth();
    int getHeight();
    float getSpeed();

    // Setters
    void setTexture(ITexture texture);
    void setWidth(int width);
    void setHeight(int height);
    void setSpeed(float speed);

    // Actions
    void draw(Canvas canvas);
    void incSpeed();
    void resize();
    void update(float delta);
    void resize(float scale);
}
