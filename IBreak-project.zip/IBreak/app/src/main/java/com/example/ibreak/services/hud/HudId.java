package com.example.ibreak.services.hud;

public enum HudId {
    LIVES_TEXT,
    SCORE_TEXT,
    SHADOW_BACKGROUND,
    TITLE_TEXT,
    CONTINUE_BUTTON,
    RETRY_BUTTON,
    EXIT_BUTTON,
}
