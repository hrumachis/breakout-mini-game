package com.example.ibreak.modules.position;

public interface IVector2f {
    // Getters
    float getX();
    float getY();

    // Setters
    IVector2f setX(float x);
    IVector2f setY(float y);
}
