package com.example.ibreak.modules.hud.builders;

import android.graphics.Color;
import android.graphics.Paint;

import com.example.ibreak.Constants;
import com.example.ibreak.modules.hud.Hud;
import com.example.ibreak.modules.hud.IHud;
import com.example.ibreak.modules.screen.Screen;

public class LivesTextHudBuilder {
    public static final IHud build() {
        IHud hud = new Hud();
        hud.getTextPos().setX((int) (80 * Screen.calcScale()));
        hud.getTextPos().setY((int) (Screen.getHeight() - 80 * Screen.calcScale()));
        hud.getTextPaint().setColor(Color.argb(240, 255, 212, 241));
        hud.getTextPaint().setTextSize((int) (36 * Screen.calcScale()));
        hud.getTextPaint().setTextAlign(Paint.Align.CENTER);
        hud.getTextPaint().setShadowLayer(10f, 0f, 0f, Color.argb(200, 255, 176, 229));
        hud.setText(Integer.toString(Constants.LIVES_INIT));
        hud.setVisibility(true);

        return hud;
    }
}
