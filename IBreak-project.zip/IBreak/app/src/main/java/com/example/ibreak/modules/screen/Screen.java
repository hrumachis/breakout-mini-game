package com.example.ibreak.modules.screen;

import android.content.res.Resources;

import com.example.ibreak.modules.position.IVector2f;
import com.example.ibreak.modules.position.Vector2f;

public class Screen {
    private static final int _defaultWidth = 2048;
    private static final int _defaultHeight = 1024;

    // Getters
    public static int getWidth() {
        return Resources.getSystem().getDisplayMetrics().widthPixels;
    }
    public static int getHeight() { return Resources.getSystem().getDisplayMetrics().heightPixels; }
    public static float getResolution() { return (float) Screen.getWidth() / (float) Screen.getHeight(); }
    public static int getWidthDefault() { return Screen._defaultWidth; }
    public static int getHeightDefault() { return Screen._defaultHeight; }
    public static float getResolutionDefault() { return (float) Screen.getWidthDefault() / (float) Screen.getHeightDefault(); }

    // Actions
    public static float calcScale() {
        float scale = 1;

        if (Screen.getResolution() > Screen.getResolutionDefault()) {
            scale =  Screen.getHeightDefault() / Screen.getHeight();
            return scale;
        }

        scale = Screen.getWidthDefault() / Screen.getWidth();

        return scale;
    }

    public static IVector2f calcOffSet() {
        IVector2f offSet = new Vector2f();

        if (Screen.getResolution() > Screen.getResolutionDefault()) {
            offSet.setY(Screen.getHeight() * (Screen.getResolution()-Screen.getResolutionDefault()) / 2);
            return offSet;
        }

        if (Screen.getResolution() < Screen.getResolutionDefault()) {
            offSet.setX(Screen.getWidth() * Math.abs((Screen.getResolution()-Screen.getResolutionDefault())) / 2);
        }

        return offSet;
    }
}

