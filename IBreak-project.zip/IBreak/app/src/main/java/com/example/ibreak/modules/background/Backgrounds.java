package com.example.ibreak.modules.background;

public enum Backgrounds {
    MAIN_BG,
}
