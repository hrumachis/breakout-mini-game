package com.example.ibreak.services.devop;

import android.graphics.Canvas;
import android.graphics.Paint;

import com.example.ibreak.modules.obstacle.IObstacle;
import com.example.ibreak.modules.position.IVector2f;
import com.example.ibreak.modules.position.Vector2f;
import com.example.ibreak.modules.texture.ITexture;

public class Pointer {
    private IVector2f _position = new Vector2f();
    private Paint _paint = new Paint();
    private boolean _visible = true;

    // Getters
    public IVector2f getPos() { return this._position; }
    public Paint getPaint() { return this._paint; }

    // Setters
    public void setVisibility(boolean visibility) { this._visible = visibility; }

    // Booleans
    public boolean isVisible() { return this._visible == true; }

    // Actions
    public void draw(Canvas canvas) {
        if (this.isVisible())
            canvas.drawRect(this.getPos().getX()-1, this.getPos().getY()-1, this.getPos().getX()+3, this.getPos().getY()+3, this.getPaint());
    }

    public void update(float delta) {

    }
}
