package com.example.ibreak.services.globals;

import android.content.res.Resources;

import com.example.ibreak.GameView;
import com.example.ibreak.services.IService;

public interface IGlobalsService extends IService {
    // Getters
    Resources getResources();
    GameView getGameView();
    GameStates getGameState();
    int getScore();
    int getLives();
    int getLevel();

    // Setters
    void setResources(Resources resources);
    void setGameView(GameView gameView);
    void setGameState(GameStates gameState);
    void setScore(int score);
    void setLives(int lives);

    // Booleans
    boolean isGameState(GameStates state);

    // Actions
    void increaseScore(int amount);
    void decreaseLives(int amount);
    void newLevel();
    void restart();
    void update();
}
