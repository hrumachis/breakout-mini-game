package com.example.ibreak.services.devop;

public enum Pointers {
    BALL_POINTER0,
    BALL_POINTER1,
    BALL_POINTER2,
    COLLISION_POINTER,
    COLLISION_AREA,
    COLLISION_SEARCH_POINTER,
    COLLISION_OFFSET,
}
