package com.example.ibreak.services.textures;

import android.content.res.Resources;
import android.graphics.BitmapFactory;

import com.example.ibreak.modules.texture.ITexture;
import com.example.ibreak.modules.texture.Texture;

public class TextureBuilder {
    public static ITexture build(Resources resources, Textures textureId) {
        ITexture texture = new Texture()
                .setImage(BitmapFactory.decodeResource(resources, TextureSelector.get(textureId)));

        return texture;
    }
}
