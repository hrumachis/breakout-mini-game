package com.example.ibreak.modules.obstacle;

import android.graphics.Canvas;
import android.util.Log;

import com.example.ibreak.modules.position.IVector2f;
import com.example.ibreak.modules.position.Vector2f;
import com.example.ibreak.modules.screen.Screen;
import com.example.ibreak.modules.texture.ITexture;
import com.example.ibreak.services.ServicesFactory;
import com.example.ibreak.services.obstacles.ObstaclesService;

public class Obstacle implements IObstacle {
    private IVector2f _position = new Vector2f();
    private ITexture _texture = null;
    private int _width = 1;
    private int _height = 1;
    private boolean _visible = true;
    private int _score = 1;

    // Getters
    public IVector2f getPos() { return this._position; }
    public ITexture getTexture() { return this._texture; }
    public int getWidth() { return this._width; }
    public int getHeight() { return this._height; }
    public int getIndex() { return (int) (1e4 * this.getPos().getX() + this.getPos().getY()); }
    public int getScore() { return this._score; }

    // Setters
    public IObstacle setTexture(ITexture texture) { this._texture = texture; return this; }
    public IObstacle setWidth(int width) { this._width = (int) Math.floor(width * Screen.calcScale()); return this; }
    public IObstacle setHeight(int height) { this._height = (int) Math.floor(height * Screen.calcScale()); return this; }
    public IObstacle setVisibility(boolean visibility) { this._visible = visibility; return this; }

    // Booleans
    public boolean isVisible() { return this._visible; }

    public boolean isCollidingDown(IVector2f pos, IVector2f velocity) {
        return pos.getY() <= this.getPos().getY() && velocity.getY() > 0;
    }

    public boolean isCollidingUp(IVector2f pos, IVector2f velocity) {
        return pos.getY() >= this.getPos().getY() && velocity.getY() < 0;
    }

    public boolean isCollidingLeft(IVector2f pos, IVector2f velocity) {
        return pos.getX() >= this.getPos().getX() && velocity.getX() < 0;
    }

    public boolean isCollidingRight(IVector2f pos, IVector2f velocity) {
        return pos.getX() <= this.getPos().getX() + this.getWidth() && velocity.getX() > 0;
    }

    // Events
    public void onCollide() {
        this.setVisibility(false);
        ServicesFactory.getGlobals().increaseScore(this.getScore());
        ServicesFactory.getEntities().getBall().incSpeed();
        ObstaclesService.getInstance().decreaseObstaclesCount();
    }

    // Actions
    public void draw(Canvas canvas) {
        if (isVisible())
            this.getTexture().draw(canvas, (int) this.getPos().getX(), (int) this.getPos().getY());
    }

    public void resize() {
        if (this.getWidth() > 0 && this.getHeight() > 0) {
            this.getTexture().resize(this.getWidth(), this.getHeight());
        }
    }
}
