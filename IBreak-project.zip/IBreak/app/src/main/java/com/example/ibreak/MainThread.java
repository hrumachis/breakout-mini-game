package com.example.ibreak;

import android.graphics.Canvas;
import android.view.SurfaceHolder;

import com.example.ibreak.modules.utils.DateUtil;

public class MainThread extends Thread {
    private SurfaceHolder surfaceHolder;
    private GameView gameView;
    private boolean running;
    public static Canvas canvas;
    private static final int FPS = 60;
    private static final int FRAME_DURATION = 1000 / MainThread.FPS;
    private long startTimestamp = DateUtil.getTimestamp();

    public MainThread(SurfaceHolder surfaceHolder, GameView gameView) {
        super();
        this.surfaceHolder = surfaceHolder;
        this.gameView = gameView;
    }

    // Getters

    // Setters
    public void setRunning(boolean isRunning) {
        running = isRunning;
    }

    // Booleans

    @Override
    public void run() {
        while (running) {
            Canvas canvas = null;
            long curentTimestamp = DateUtil.getTimestamp();
            float delta = (curentTimestamp - this.startTimestamp) / MainThread.FRAME_DURATION;

            if (delta > 1e5)
                delta = 1;

            this.startTimestamp = curentTimestamp;

            try {
                canvas = this.surfaceHolder.lockCanvas();
                synchronized(surfaceHolder) {
                    this.gameView.update(delta);
                    this.gameView.draw(canvas);
                }

                Thread.sleep(MainThread.FRAME_DURATION);
            } catch (Exception e) {} finally {
                if (canvas != null) {
                    try {
                        surfaceHolder.unlockCanvasAndPost(canvas);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }
}
