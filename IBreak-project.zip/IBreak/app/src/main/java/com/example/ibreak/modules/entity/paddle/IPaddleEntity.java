package com.example.ibreak.modules.entity.paddle;

import com.example.ibreak.modules.entity.IEntity;

public interface IPaddleEntity extends IEntity {
}
