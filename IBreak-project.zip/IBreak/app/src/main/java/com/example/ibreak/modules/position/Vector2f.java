package com.example.ibreak.modules.position;

public class Vector2f implements IVector2f {
    private float _x = 0;
    private float _y = 0;

    // Getters
    public float getX() { return this._x; }
    public float getY() { return this._y; }

    // Setters
    public IVector2f setX(float x) { this._x = x; return this; }
    public IVector2f setY(float y) { this._y = y; return this; }

    // Booleans
}
